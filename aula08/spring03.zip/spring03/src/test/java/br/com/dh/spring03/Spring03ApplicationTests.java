package br.com.dh.spring03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
